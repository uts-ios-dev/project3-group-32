//
//  ViewControllerTableViewCell.swift
//  Mustage
//
//  Created by josh parker on 31/1/18.
//  Copyright © 2018 Bossly. All rights reserved.
//

import UIKit

class ViewControllerTableViewCell: UITableViewCell {
    
    
    //labels connected
    @IBOutlet weak var labelName: UILabel!  // name is the category of prefilled bet
    @IBOutlet weak var labelGenre: UILabel! //bet pool amount
    @IBOutlet weak var DescriptionBetLabel: UILabel!  //description
    @IBOutlet weak var ActualNameLabel: UILabel!  // name user entered
    @IBOutlet weak var Bet1Label: UILabel! /// Bet 1 vs
    @IBOutlet weak var Bet2Label: UILabel! // vs bet2
    @IBOutlet weak var BettingImage: UIImageView!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        //      var image: UIImage = UIImage(named: labelName.text! + ".jpg")!
        //     BettingImage = UIImageView(image: image)
        
     //   UniversalTitle = labelName.text
        //   UniversalName = LabelNamey.text
     //   UniversalBetSize = labelGenre.text
     //   UniversalName = DescriptionBetLabel.text
        
        UniversalActualName = ActualNameLabel.text
        UniversalPersonA = Bet1Label.text
   //     UniversalPersonB = Bet2Label.text
   //     print("Right Below")
   //     print(UniversalPersonA)
   //     print(UniversalPersonB)
    //    print("Right Above")
        
        
        // Configure the view for the selected state
    }
    
}

