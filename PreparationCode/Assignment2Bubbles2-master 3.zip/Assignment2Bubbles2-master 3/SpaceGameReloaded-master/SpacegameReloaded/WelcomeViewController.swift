//
//  AuthViewController.swift
//
//  Created by Bossly on 9/10/16.
//  Copyright © 2016 Bossly. All rights reserved.
//
/*
import UIKit
//import Firebase
//import FirebaseAuth
//import FirebaseAuthUI

//import FirebaseGoogleAuthUI
import FirebaseFacebookAuthUI
import FirebaseTwitterAuthUI
import FirebasePhoneAuthUI

class WelcomeViewController: UIViewController, FUIAuthDelegate {
    
    @IBOutlet weak var progressView:UIView? // view shown while data is loading
    @IBOutlet weak var welcomeView:UIView? // view when data is loaded. like sign-in or intro
    
    override func viewDidLoad() {
        
        //   UniversalProfileName = currentUser?.name
        
        self.welcomeView?.isHidden = true
        self.progressView?.isHidden = false
        
        let config = RemoteConfig.remoteConfig()
        #if DEBUG
            config.configSettings = RemoteConfigSettings(developerModeEnabled: true)
        #endif
        
        config.fetch(withExpirationDuration: 100) { (status, error) -> Void in
            if status == .success {
                print("Config fetched!")
                config.activateFetched()
            } else {
                print("Config not fetched")
                print("Error: \(error?.localizedDescription ?? "No error available.")")
            }
            
            self.defineTheme(config)
            self.welcomeView?.isHidden = false
            self.progressView?.isHidden = true
            
            // if user authorized, go to main page
            if (Auth.auth().currentUser) != nil {
                self.performSegue(withIdentifier: "auth.mute", sender: nil)
            }
        }
    }
    
    // FIRAuthUIDelegate
    
    func authUI(_ authUI: FUIAuth, didSignInWith user: User?, error: Error?) {
        if let errorHandler = error as NSError? {
            self.showError(errorHandler.localizedDescription)
            // print user-info. find more here: https://firebase.google.com/docs/auth/ios/errors
            print(errorHandler.userInfo)
        } else {
            if let currentUser = user {
                UserModel.collection.child(currentUser.uid).queryOrderedByKey().observeSingleEvent(of: .value, with: { (snapshot) in
                    
                    // if snapshot is empty, means user is not created yet
                    if snapshot.childrenCount == 0 {
                        
                        // update displayname and photo
                        let userdata = UserModel(currentUser.uid)
                        userdata.name = currentUser.displayName ?? kDefaultUsername
                        userdata.photo = currentUser.photoURL?.absoluteString ?? kDefaultProfilePhoto
                        userdata.saveData()
                    }
                })
            }
            
            self.performSegue(withIdentifier: "auth", sender: nil)
        }
    }
    
    // Helpers
    
    func showError(_ error:String) {
        print("Error: \(error)")
        
        let alert = UIAlertController(title: kAlertErrorTitle, message: error, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: kAlertErrorDefaultButton, style: .default) { (action) in })
        self.present(alert, animated: true) {}
    }
    
    func defineTheme(_ config:RemoteConfig) {
        var primary = UIColor.white
        var secondary = UIColor.blue
        
        if let string = config[kPrimaryColor].stringValue, !string.isEmpty {
            primary = UIColor(hexString: string)!
        }
        
        if let string = config[kSecondaryColor].stringValue, !string.isEmpty {
            secondary = UIColor(hexString: string)!
        }
        
        UINavigationBar.appearance().barTintColor = primary
        UINavigationBar.appearance().tintColor = secondary
        UIBarButtonItem.appearance().setTitleTextAttributes(
            [NSAttributedStringKey.foregroundColor:secondary], for: UIControlState.normal)
        
        UITabBar.appearance().barTintColor = primary
        UITabBar.appearance().tintColor = secondary
        
        UIButton.appearance().tintColor = secondary
    }
    
    // Actions
    @IBAction func buttonPressed(_ sender: AnyObject) {
        let authUI = FUIAuth.defaultAuthUI()
        authUI?.delegate = self
        
        /*
         * Uncommend this lines to add Google and Facebook authorization. But first
         * enabled it in Firebase Console. More information you can find here:
         * https://firebase.google.com/docs/auth/ios/google-signin
         * https://firebase.google.com/docs/auth/ios/facebook-login
         */
        let providers: [FUIAuthProvider] = [
            FUIGoogleAuth(),
            FUIFacebookAuth(),
            FUITwitterAuth(),
            FUIPhoneAuth(authUI:authUI!),
            ]
        authUI?.providers = providers
        /*
         kEulaUrl needs to be set in Config.swift file. required for publishing
         */
        authUI?.tosurl = URL(string:kEulaUrl)
        
        if (Auth.auth().currentUser) != nil {
            self.performSegue(withIdentifier: "auth.mute", sender: nil)
        } else {
            let authViewController = authUI!.authViewController()
            
            self.present(authViewController, animated: true) {
                // ..
            }
        }
    }
    
} */
