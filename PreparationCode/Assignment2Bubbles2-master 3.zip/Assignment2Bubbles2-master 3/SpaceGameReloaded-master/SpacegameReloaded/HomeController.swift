//
//  HomeController.swift
//  SpacegameReloaded
//
//  Created by Joshua Parker on 1/5/18.
//  Copyright © 2018 Training. All rights reserved.
//

import UIKit

var NameOfPlayer : String!
class HomeController: UIViewController {

    @IBOutlet weak var UserTextField: UITextField!
    @IBOutlet weak var UserNameLabel: UILabel!
    
    override func viewDidLoad() {
        if (score != nil) {
            if (UniversalhighScore == nil) {
                UniversalhighScore = 0
            }
        if (score > UniversalhighScore) {
        if (NewHighScoreAlert == 1) {
        let alert = UIAlertController(title: "New HighScore", message: "Congratulations \(NameOfPlayer!) you made a new high score!", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
            switch action.style{
            case .default:
                
                presentView = 1
            
            case .cancel:
                print("cancel")
                
            case .destructive:
                print("destructive")
                
                
            }}))
        
        
        self.present(alert, animated: true, completion: nil)
        NewHighScoreAlert = 0
    }
        }
        }
        super.viewDidLoad()

        
        UserNameLabel.text = UserTextField.text
        NameOfPlayer = UserNameLabel.text
        if (score != nil) {
            if (UniversalhighScore == nil) {
                UniversalhighScore = 0
            }
            if (score > UniversalhighScore) {
                if (NewHighScoreAlert == 1) {
                    let alert = UIAlertController(title: "New HighScore", message: "Congratulations \(NameOfPlayer!) you made a new high score!", preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
                        switch action.style{
                        case .default:
                            
                            presentView = 1
                            
                        case .cancel:
                            print("cancel")
                            
                        case .destructive:
                            print("destructive")
                            
                            
                        }}))
                    
                    
                    self.present(alert, animated: true, completion: nil)
                    NewHighScoreAlert = 0
                }
            }
        }
      //   UserNameLabel.text = UserTextField.text
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func PlayButtonPressed(_ sender: Any) {
         resetTime = 1
          NameOfPlayer = UserTextField.text
        if (TimeOfGameInt != nil) {
        time = TimeOfGameInt
        } else {
            time = 60
        }
        GameOver = 0
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        UserNameLabel.text = UserTextField.text
        NameOfPlayer = UserNameLabel.text
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
