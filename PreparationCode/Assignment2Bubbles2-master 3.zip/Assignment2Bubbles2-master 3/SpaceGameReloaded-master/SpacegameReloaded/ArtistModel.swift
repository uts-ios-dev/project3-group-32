//
//  ArtistModel.swift
//
//
//  Created by josh parker on 31/1/18.
//  Copyright © 2018 Bossly. All rights reserved.
//
import Foundation
class ArtistModel {
    
    var id: String?
    var name: String?
    var genre: String?
    var description: String?
    var ActualName: String?
    var PersonA: String?
    var PersonB: String?
    var ImageName: String?
    var NameOfCreator: String?
    
    
    init(id: String?, name: String?, genre: String?, description: String?, ActualName: String?, PersonA: String?, PersonB: String?, ImageName: String?, NameOfCreator: String?){
        self.id = id
        self.name = name
        self.genre = genre
        self.description = description
        self.ActualName = ActualName
        self.PersonA = PersonA
        self.PersonB = PersonB
        self.ImageName = ImageName
        self.NameOfCreator = NameOfCreator
        
    }
}
