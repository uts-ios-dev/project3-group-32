//
//  TableViewController.swift
//  Mustage
//
//  Created by josh parker on 1/2/18.
//  Copyright © 2018 Bossly. All rights reserved.
//

//
//  TableViewController.swift
//  cellFun
//
//  Created by Sebastian Hette on 04.04.2017.
//  Copyright © 2017 MAGNUMIUM. All rights reserved.
//

import UIKit
import Firebase

var pets2 = ["dog", "cat", "rabbit"]
var petDesc2 = ["Dog is an animal that has four legs", "A cat is an animal that likes to eat fish", "A rabbit is an animal that likes to jump arond"]
var myIndex2 = 0
var UniversalTitle: String!
var UniversalName: String!
var UniversalBetSize: String!
var UniversalActualName: String!
var UniversalPersonA: String!
var UniversalPersonB: String!
var UniversalImageName2: String!
var UniversalNameOfCreator: String!
var UniversalPrivacyBetIndicator: String!
var IDForBet: String!
var UniversalhighScore : Double!
var UniversalhighScoreName : String!
let userDefults = UserDefaults.standard //returns shared defaults object.
var newScoreAcheived : Int!


class TableViewController: UITableViewController{
    
    // MARK: - Table view data source
    
    
    //defining firebase reference var
    var refArtists: DatabaseReference!
       var dbHandleQuery: DatabaseHandle?
    
    let blogSegueIdentifier = "ShowBlogSegue"
    var artistList = [ArtistModel]()
    //   static var isAlreadyLaunchedOnce = false // Used to avoid 2 FIRApp configure
    
    //   @IBOutlet weak var textFieldName: UITextField!
    // @IBOutlet weak var textFieldGenre: UITextField!
    @IBOutlet weak var labelMessage: UILabel!
    //  @IBOutlet weak var ButtonToBeHidden: UIButton!
    
    @IBOutlet weak var MainHighScoreLabel: UILabel!
    
    @IBOutlet weak var MainHighScoreName: UILabel!
    
    @IBOutlet weak var tableViewArtists: UITableView!
    
    //list to store all the artist
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return artistList.count
        //      return pets2.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        //creating a cell using the custom class
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ViewControllerTableViewCell
        
        //the artist object
        let artist: ArtistModel
        
        //getting the artist of selected position
        artist = artistList[indexPath.row]
        // cell.BettingImage = artist.image
        //adding values to labels
    //    cell.labelName.text = artist.name
     //   cell.labelGenre.text = artist.genre
      //  cell.DescriptionBetLabel.text = artist.description
      cell.ActualNameLabel.text = artist.ActualName
        cell.Bet1Label.text = artist.PersonA
     //   cell.Bet2Label.text = artist.PersonB
        // cell.textLabel?.text = pets2[indexPath.row]
        
        if (artist.ImageName != nil) {
            if let photo = URL(string:artist.ImageName!) {
                
            }
        }
        //returning cell
        return cell
        
        
    }
    
    
    
    
    
    
    
    
    
    //   @IBAction func buttonAddArtist(_ sender: UIButton) {
    //      addArtist()
    // }
    
    override func viewDidLoad() {
             self.tableView.reloadData()
      
            
        if FirebaseApp.app() == nil {
            FirebaseApp.configure()
        }
        
        
        
        
        struct content {
            var sTitle : String!
            var sValue : Any!
            
            init(sTitle: String, sValue: Any) {
                self.sTitle = sTitle
                self.sValue = sValue
            }
        }
        
        
     
        
        
     
        
        
        super.viewDidLoad()
    
        
        if let highScore = userDefults.value(forKey: "highScore") {
           let highScoreName = userDefults.value(forKey: "highScoreName")
            if (highScoreName != nil) {
            UniversalhighScoreName = highScoreName as! String
            } else {
                UniversalhighScoreName = "Needed"
            }
            UniversalhighScore = highScore as! Double
            if (UniversalhighScore != nil) {
           MainHighScoreLabel.text = String(UniversalhighScore!)
            } else {
                 MainHighScoreLabel.text = ""
            }
            MainHighScoreName.text = UniversalhighScoreName
        } else {
            UniversalhighScore = 0
            
        }
        //  ButtonToBeHidden.isHidden = true
        // textFieldName.isHidden = true
        //textFieldGenre.isHidden = true
        
        // self.view.addGestureRecognizer(UITapGestureRecognizer(target: self.view, action: #selector(UIView.endEditing(_:))))
            refArtists = Database.database().reference().child("Bets");
        
        print("Above after database load")
        //observing the data changes
        refArtists.observe(DataEventType.value, with: { (snapshot) in
            
            //if the reference have some values
            if snapshot.childrenCount > 0 {
                
                //clearing the list
                self.artistList.removeAll()
                
                
                
                //iterating through all the values
                for artists in snapshot.children.allObjects as! [DataSnapshot] {
                    //getting values
                    let artistObject = artists.value as? [String: AnyObject]
                    let artistName  = artistObject?["TypeOfBet"]
                    let artistActualName = artistObject?["NameOfBet"]
                    let artistPersonA = artistObject?["PersonA"]
                    let artistPersonB = artistObject?["PersonB"]
                    let artistId  = artistObject?["id"]
                    let artistGenre = artistObject?["WinningOptions"]
                    let artistDescription = artistObject?["Description"]
                    let artistImageLabel = artistObject?["ImageName"]
                    let artistNameOfCreator = artistObject?["NameOfPerson"]
                    
                    
                    //creating artist object with model and fetched values
                    let artist = ArtistModel(id: artistId as! String?, name: artistName as! String?, genre: artistGenre as! String?, description: artistDescription as! String?, ActualName: artistActualName as! String?, PersonA: artistPersonA as! String?, PersonB: artistPersonB as! String?, ImageName: artistImageLabel as! String?, NameOfCreator: artistNameOfCreator as! String?)
                    self.tableView.dataSource = self;
                    
                    UniversalImageName2 = artist.ImageName
                    //appending it to list
                    self.artistList.append(artist)
                    
                    
               //////
                    self.dbHandleQuery =  self.refArtists.queryOrdered(byChild:"NameOfBet").observe( .value, with: {(snapshot) in
                        var counter = 0
                        var newContent : [content] = []
                        for snap in snapshot.children.allObjects as! [DataSnapshot] {
                            
                            counter += 1
                            let title = snap.key as String
                            if let rankedBy = snap.value as? [String : Any]  {
                                
                                newContent.append(content(sTitle: "\(counter).\(title)", sValue: rankedBy["NameOfBet"] as Any))
                                self.tableView.reloadData()
                            }
                        }
                    
                        self.tableView.reloadData()
                    })
                    ///////
                }
                self.tableView.reloadData()
                //reloading the tableview
                //  self.tableViewArtists.reloadData()
                // self.tableView.reloadData()
            }
        })
    }
    
    
    
    /*   @IBAction func PrivateBetsButton(_ sender: Any) {
     UniversalPrivacyBetIndicator = "Private"
     refArtists = Database.database().reference().child("PrivateBets");
     self.tableView.reloadData()
     print(UniversalPrivacyBetIndicator)
     print("Above after private bets button")
     }
     @IBAction func PublicBetsButton(_ sender: Any) {
     UniversalPrivacyBetIndicator = "Public"
     self.tableView.reloadData()
     } */
    // func dismissKeyboard() {
    //    textFieldName.resignFirstResponder()
    // }
    
    /*  func addArtist(){
     //generating a new key inside artist s node
     //and also getting the generated key
     let key = refArtists.childByAutoId().key
     
     //creating artist with the given values
     let artist = ["id":key*
     "artistName": textFieldName.text! as String,
     "artistGenre": textFieldGenre.text! as String
     ]
     
     //adding the artist inside the generated unique key
     refArtists.child(key).setValue(artist)
     
     //displaying message
     labelMessage.text = "Artist Added"
     }*/
     override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            self.tableView.reloadData()
        print("WORKING")
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /* func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
     
     //   let destination = UIViewController() // Your destination
     //  navigationController?.pushViewController(destination, animated: true)
     tableView.deselectRow(at: indexPath, animated: true)
     
     let row = indexPath.row
     print("Yay its working")
     
     
     myIndex = indexPath.row
     print("Pressing")
     
     } */
    
    
    
    public override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        myIndex2 = indexPath.row
        // performSegue(withIdentifier: "segue", sender: nil)
        //        presentViewController(TestViewController, animated: true, completion: nil)
    }
    
    
    
}


