//
//  GameViewController.swift
//  SpacegameReloaded
//
//  Created by Training on 01/10/2016.
//  Copyright © 2016 Training. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit
import Firebase
import FirebaseDatabase
var presentView : Int!
var ItsbeenPlayed : Int!
var highscore: Double!
var TimeisZero : Int!
var NewHighScoreAlert : Int!
var alreadyAlert : Int!
    var ref: DatabaseReference!

class GameViewController: UIViewController {
    
    var countdownTimer = Timer()
    var ChangeViewTimer = Timer()
    var circleRecognizer: GameScene!

    override func viewDidLoad() {
         presentView = 0
        print("Current HighScore\(highscore)")
        
        let userDefults = UserDefaults.standard
     
            TimeisZero = 1
        
        if let highScore = userDefults.value(forKey: "highScore") { //Returns the integer value associated with the specified key.
            //do something here when a highscore exists
            highscore = highScore as! Double
            
        } else {
            //no highscore exists
            highscore = 0
            
        }
        
        
        super.viewDidLoad()
   
        if (presentView == 1) {
           
            
            ChangeViewTimer = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(clockCountDown3), userInfo: nil, repeats: true)
        }
        
        if (GameOver == 0) {
        countdownTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(clockCountDown2), userInfo: nil, repeats: true)
        }
        
        if (ChangeBubleTime == 1) {
            let randombubblesAction = GKRandomDistribution(lowestValue:1, highestValue: SpeedThatBubblesCome)
            SpeedThatBubblesCome = (randombubblesAction.nextInt())
           ChangeBubleTime = 0
        }
        
      
            
            
     if let view = self.view as! SKView? {
            // Load the SKScene from 'GameScene.sks'
            if let scene = SKScene(fileNamed: "GameScene") {
                // Set the scale mode to scale to fit the window
                scene.scaleMode = .aspectFill
                
                // Present the scene
                view.presentScene(scene)
            }
            
            view.ignoresSiblingOrder = true
            
            view.showsFPS = true
            view.showsNodeCount = true
        }
        
       
        
    }


    
    
    
    @IBAction func createQuestion(_ sender: Any) {
        
        ref = Database.database().reference(fromURL: "https://fir-database-12782.firebaseio.com/")
       
            // ok i need to save the highest high scores 
            
            let key = ref.childByAutoId().key
            
            //    ref.child("Bets").childByAutoId().setValue(["TypeOfBet": optionA.text, "WinningOptions": optionB.text, "Description": correctAnswer.text, "NameOfBet": questionField.text, "ID": key])
        let artist = ["id":key,
                      "NameOfBet": NameOfPlayer! as String,
                      "PersonA": String(score) as String
                // "myImageURL" : myImageView as UIImageView!
                
            ]
            
        
            ref.child("Bets").child(key).setValue(artist)
        ///////
        
   
            
            ////////
     /*
            
            self.present(alert2, animated: true, completion: nil)
            alert2.addAction(UIAlertAction(title: "Ok", style: .default, handler: { action in
                switch action.style{
                case .default:
                    print("default")
                    
                case .cancel:
                    print("cancel")
                    
                case .destructive:
                    print("destructive")
                    
                    
                }})) */
            
            
            /*      self.ref?.child("Questions").setValue(["Name Of Bet": questionField.text, "Bet Description": correctAnswer.text, "Time Of Bet": optionA.text, "Amount Of Bet": optionB.text]) */
            // ref.child("Questions").childByAutoId().setValue(...)
            
      
        
    }
    
      func clockCountDown3() {
        alreadyAlert = 1
        
        let alert = UIAlertController(title: "New HighScore", message: "Congratulations \(NameOfPlayer!) you made a new high score!", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
            switch action.style{
            case .default:
              self.exitScreen()
                
            case .cancel:
                print("cancel")
                
            case .destructive:
                print("destructive")
                
                
            }}))
 
        
        self.present(alert, animated: true, completion: nil)
      
       
    }
    
    func DidNotGetHighScore() {
        
        if (alreadyAlert != 1) {
        let alert2 = UIAlertController(title: "Oh No!", message: "Better luck next time \(NameOfPlayer!)!", preferredStyle: UIAlertControllerStyle.alert)
        alert2.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
            switch action.style{
            case .default:
                self.exitScreen()
                
            case .cancel:
                print("cancel")
                
            case .destructive:
                print("destructive")
                
                
            }}))
        
        
        self.present(alert2, animated: true, completion: nil)
        
        }
    }
    
    
    func exitScreen() {
        
        navigationController?.popViewController(animated: true)
        dismiss(animated: true, completion: nil)
    }
    
    func clockCountDown2() {
        
        if (time > 0) {
          //  if (ItsbeenPlayed != 1) {
            let time2 = time - 1
            time = time2
        //    }
        } else if (time < 1) {
            
          
        
            
            if (score > UniversalhighScore) {
                self.clockCountDown3()
                
            }
            if (score <= UniversalhighScore){
              self.DidNotGetHighScore()
            }
            
         
        
            GameOver = 1
       
            NewHighScoreAlert = 1
            
               ChangeBubleTime = 0
            ItsbeenPlayed = 1
            if (UniversalhighScore != nil) {
            if (score > UniversalhighScore) {
                newScoreAcheived = 1
                print("new score is acheiving\(newScoreAcheived)")
                UniversalhighScore = score
                UniversalhighScoreName = NameOfPlayer
                userDefults.set(UniversalhighScore, forKey: "highScore")
                if (UniversalhighScoreName == nil) {
                    UniversalhighScoreName = "User"
                }
                userDefults.set(UniversalhighScoreName, forKey: "highScoreName")
                   print("NEW HIGH SCORE!!!!!!\(UniversalhighScore)")
                 print("highscorename:\(UniversalhighScoreName)")
                
            }
            }
          if (UniversalhighScore == nil) {
                 userDefults.set(score, forKey: "highScore")
             userDefults.set(UniversalhighScoreName, forKey: "highScoreName")
            UniversalhighScore = score
            UniversalhighScoreName = NameOfPlayer
            print("NEW HIGH SCORE!!!!!!\(UniversalhighScore)")
            }
        
            
            if (TimeisZero == 1) {
                ref = Database.database().reference(fromURL: "https://fir-database-12782.firebaseio.com/")
                
                
                
                let key2 = ref.childByAutoId().key
                 let key = String(score)
                
                //    ref.child("Bets").childByAutoId().setValue(["TypeOfBet": optionA.text, "WinningOptions": optionB.text, "Description": correctAnswer.text, "NameOfBet": questionField.text, "ID": key])
                let artist = ["id":key,
                              "NameOfBet": NameOfPlayer! as String,
                              "PersonA": String(score) as String
                    // "myImageURL" : myImageView as UIImageView!
                    
                ]
                
                
                ref.child("Bets").child(key2).setValue(artist)
                
                TimeisZero = 0
                
                
            }
           
            
            if (highscore < score) {
                
            let userDefults = UserDefaults.standard
            userDefults.set(highscore, forKey: "highScore") //Sets the value of the specified default key to the specified integer value
            userDefults.synchronize() // don't forget this!!!!
                highscore = score
                print("New High Score!")
            }
            
    

        }
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
 
    override func viewWillDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
         countdownTimer.invalidate()
        
        }
   
    
    
    func myTapAction(sender : UITapGestureRecognizer) {
        // Do what you want
    }
    
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }
}
