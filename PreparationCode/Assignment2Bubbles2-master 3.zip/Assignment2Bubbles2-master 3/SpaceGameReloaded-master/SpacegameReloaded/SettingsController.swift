//
//  SettingsController.swift
//  SpacegameReloaded
//
//  Created by josh parker on 6/5/18.
//  Copyright © 2018 Training. All rights reserved.
//

import UIKit

var NumberOfBubblesInt : Int!
var TimeOfGameInt : Int!
var SpeedThatBubblesCome : Int!
class SettingsController: UIViewController {

    @IBOutlet weak var TimeOfGame: UILabel!
    @IBOutlet weak var AmountOfBubbles: UILabel!
    override func viewDidLoad() {
        
        NumberOfBubblesInt = 15
          SpeedThatBubblesCome = NumberOfBubblesInt
        TimeOfGameInt = 60
        super.viewDidLoad()
    
        TimeOfGame.text = String(TimeOfGameInt)
        AmountOfBubbles.text = String(NumberOfBubblesInt)
        
        SpeedThatBubblesCome = NumberOfBubblesInt
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func PlusBubblesAction(_ sender: Any) {
        if (NumberOfBubblesInt > 14) {
            print("maximum number of bubbles is 15")
            
        } else if (NumberOfBubblesInt < 15) {
              NumberOfBubblesInt = NumberOfBubblesInt! + 1
        }
         AmountOfBubbles.text = String(NumberOfBubblesInt)
          SpeedThatBubblesCome = NumberOfBubblesInt
    }
   
    @IBAction func MinusBubblesAction(_ sender: Any) {
        
        if (NumberOfBubblesInt > 1) {
            NumberOfBubblesInt = NumberOfBubblesInt! - 1
        } else if (NumberOfBubblesInt < 2) {
            print("There as to be at least 1 bubbles")
        }
              AmountOfBubbles.text = String(NumberOfBubblesInt)
          SpeedThatBubblesCome = NumberOfBubblesInt
    }
    
    

    @IBAction func PlusTimeOfGame(_ sender: Any) {
        if (TimeOfGameInt < 60) {
            TimeOfGameInt = TimeOfGameInt! + 1
        } else if (TimeOfGameInt > 59) {
            print("Maximum amount of time is 60 Seconds")
        }
        TimeOfGame.text = String(TimeOfGameInt)
    }
    
    @IBAction func MinusTimeOfGame(_ sender: Any) {
             print("Minus is pressed")
        if (TimeOfGameInt > 1) {
               print(TimeOfGameInt)
            TimeOfGameInt = TimeOfGameInt! - 1
        } else if (TimeOfGameInt < 2) {
            print("There must be at least 1 second in the game")
        }
        TimeOfGame.text = String(TimeOfGameInt)
    }
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    

}
