//
//  GameScene.swift
//  SpacegameReloaded
//
//  Created by Training on 01/10/2016.
//  Copyright © 2016 Training. All rights reserved.
//

import SpriteKit
import GameplayKit
import CoreMotion
import UIKit.UIGestureRecognizerSubclass
var time: Int!
var score: Double!
var CheckingBubblesDontOverlapx : Int!
var CheckingBubblesDontOverlapy : Int!
var HowManyBubbles : Double!
var ChangeBubleTime: Int!
var GameOver : Int!
var BetterScore : Int!
var previousString : String!
var resetTime : Int!
var TimerUntilStartOfGameInt : Int!
var counting : Int!
/// if bubbles move off the screen they go faster
//flashing down 3 2 1 before the game begins
// show high score during games
// if two or more bubbles of the same colour are popped then there is a 1.5x score added
// display high score during game play

class GameScene: SKScene, SKPhysicsContactDelegate, UIGestureRecognizerDelegate {
    var starfield:SKEmitterNode!
    var BlackBubbles = SKSpriteNode()
    var shipIsTouched = false
   
   // var player:SKSpriteNode!

 
    var scoreLabel:SKLabelNode!
    var timeLabel:SKLabelNode!
    var HighScoreLabel:SKLabelNode!
     var TimeToStartGame:SKLabelNode!
   /* var score:Int = 0 {
        didSet {
            scoreLabel.text = "Score: \(score)"
        }
    }*/
    
    

    var AnimationSpeed = 6
    var gameTimer:Timer!
    var  countdownTimer : Timer!
    var  GameOverTimer : Timer!
    var TimerUntilGameStartsTimer : Timer!
    
    var possibleAliens = ["RedBubbles", "RedBubbles", "RedBubbles", "RedBubbles", "RedBubbles", "RedBubbles", "RedBubbles", "RedBubbles", "PinkBubbles", "PinkBubbles", "PinkBubbles", "PinkBubbles", "PinkBubbles", "PinkBubbles", "GreenBubbles", "GreenBubbles", "GreenBubbles", "BlueBubbles", "BlueBubbles", "BlackBubbles"]
    
   
    /// sooooo there's probably better ways of doing this. But red has a 40%, pink 30%, Green 15%, Blue 10% and black 5%. I just made 20 in total :)
    
    
    let alienCategory:UInt32 = 0x1 << 1
    let photonTorpedoCategory:UInt32 = 0x1 << 0
    
    
    let motionManger = CMMotionManager()
    var xAcceleration:CGFloat = 0
    
   
    override func didMove(to view: SKView) {
        
      /*  starfield = SKEmitterNode(fileNamed: "Starfield")
        starfield.position = CGPoint(x: 0, y: 1472)
        starfield.advanceSimulationTime(10)
        self.addChild(starfield)
        
        starfield.zPosition = -1
         

         
 
 */
  
        
        
        self.physicsWorld.gravity = CGVector(dx: 0, dy: 0)
        self.physicsWorld.contactDelegate = self
        
        scoreLabel = SKLabelNode(text: "Score: 0")
        scoreLabel.position = CGPoint(x: 310, y: self.frame.size.height - 60)
        scoreLabel.fontName = "AmericanTypewriter-Bold"
        scoreLabel.fontSize = 30
        scoreLabel.fontColor = UIColor.white
        score = 0
        
        self.addChild(scoreLabel)
        
        timeLabel = SKLabelNode(text: "Time: 0")
        timeLabel.position = CGPoint(x: 100, y: self.frame.size.height - 60)
        timeLabel.fontName = "AmericanTypewriter-Bold"
        timeLabel.fontSize = 36
        timeLabel.fontColor = UIColor.white

        self.addChild(timeLabel)
        
        HighScoreLabel = SKLabelNode(text: "HighScore: 0")
        HighScoreLabel.position = CGPoint(x: 200, y: self.frame.size.height - 650)
        HighScoreLabel.fontName = "AmericanTypewriter-Bold"
        HighScoreLabel.fontSize = 36
        HighScoreLabel.fontColor = UIColor.white
        if (UniversalhighScore == nil) {
            UniversalhighScore = 0
        }
        self.addChild(HighScoreLabel)
        
        TimeToStartGame = SKLabelNode(text: "Begin!")
        TimeToStartGame.position = CGPoint(x: 200, y: self.frame.size.height - 350)
        TimeToStartGame.fontName = "AmericanTypewriter-Bold"
        TimeToStartGame.fontSize = 80
        TimeToStartGame.fontColor = UIColor.white
       
        self.addChild(TimeToStartGame)
        
        
        /// if more aliens wanted the timer interval is decreased
        HowManyBubbles = 0.0
       
        if (SpeedThatBubblesCome != nil) {
            
      //      let randombubblesAction = GKRandomDistribution(lowestValue:1, highestValue: SpeedThatBubblesCome)
       //     SpeedThatBubblesCome = (randombubblesAction.nextInt())
            if (SpeedThatBubblesCome == 15) {
                HowManyBubbles = 0.45
            }
            if (SpeedThatBubblesCome == 14) {
                HowManyBubbles = 0.50
            }
            if (SpeedThatBubblesCome == 13) {
                HowManyBubbles = 0.51
            }
            if (SpeedThatBubblesCome == 12) {
                HowManyBubbles = 0.52
            }
            if (SpeedThatBubblesCome == 11) {
                HowManyBubbles = 0.53
            }
            if (SpeedThatBubblesCome == 10) {
                HowManyBubbles = 0.55
            }
            if (SpeedThatBubblesCome == 9) {
                HowManyBubbles = 0.65
            }
            if (SpeedThatBubblesCome == 8) {
                HowManyBubbles = 0.70
            }
            if (SpeedThatBubblesCome == 7) {
                HowManyBubbles = 0.62
            }
            if (SpeedThatBubblesCome == 6) {
                HowManyBubbles = 0.78
            }
            if (SpeedThatBubblesCome == 5) {
                HowManyBubbles = 0.85
            }
            if (SpeedThatBubblesCome == 4) {
                HowManyBubbles = 0.95
            }
            if (SpeedThatBubblesCome == 3) {
                HowManyBubbles = 1.3
            }
            if (SpeedThatBubblesCome == 2) {
                HowManyBubbles = 2
            }
            if (SpeedThatBubblesCome == 1) {
                HowManyBubbles = 4.2
            }
         //HowManyBubbles = Double(SpeedThatBubblesCome/30)
        } else {
            HowManyBubbles = 0.75
        }
        if (TimerUntilStartOfGameInt == nil) {
            TimerUntilStartOfGameInt = 1
        }
        if (TimerUntilStartOfGameInt > 0) {
        TimerUntilGameStartsTimer = Timer.scheduledTimer(timeInterval:1, target: self, selector: #selector(TimeUnilTheGameBegins), userInfo: nil, repeats: true)
        }
        
        
        if (GameOver == 0) {
      
          gameTimer = Timer.scheduledTimer(timeInterval:HowManyBubbles, target: self, selector: #selector(addAlien), userInfo: nil, repeats: true)
        
          
         
            
            
        countdownTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(clockCountDown), userInfo: nil, repeats: true)
        let Movementcheck =   HowManyBubbles * 3
      
        }
    
        
        motionManger.accelerometerUpdateInterval = 0.2
        motionManger.startAccelerometerUpdates(to: OperationQueue.current!) { (data:CMAccelerometerData?, error:Error?) in
            if let accelerometerData = data {
                let acceleration = accelerometerData.acceleration
                self.xAcceleration = CGFloat(acceleration.x) * 0.75 + self.xAcceleration * 0.25
            }
        }
        
        
        
    }
    func TimeUnilTheGameBegins() {
        counting = 1
        counting = counting! - 1
        TimerUntilStartOfGameInt = counting
        
        TimeToStartGame.text = String(TimerUntilStartOfGameInt)
        //countdown
        if (counting < 1) {
            TimeToStartGame.text = ""
             TimerUntilGameStartsTimer.invalidate()
        }
    }
    
    func clockCountDown() {
        if (BetterScore == 1) {
          scoreLabel.text = "1.5 Score: \(score)"
        } else {
               scoreLabel.text = "Score: \(score)"
        }
          timeLabel.text = "Time: \(time)"
        HighScoreLabel.text = "HighScore: \(UniversalhighScore!)"
        
        
  
        
        var FormattedString2 = timeLabel.text?.replacingOccurrences(of: "Optional", with: "")
        FormattedString2 = FormattedString2?.replacingOccurrences(of: ")", with: "")
        FormattedString2 = FormattedString2?.replacingOccurrences(of: "(", with: "")
        var FormattedString3 = scoreLabel.text?.replacingOccurrences(of: "Optional", with: "")
        FormattedString3 = FormattedString3?.replacingOccurrences(of: ")", with: "")
        FormattedString3 = FormattedString3?.replacingOccurrences(of: "(", with: "")
        scoreLabel.text = FormattedString3
        timeLabel.text = FormattedString2
      //     print("this is the text\(timeLabel.text)")
      
        if (time > 0) {
          //  let time2 = time - 1
         //   time = time2
        } else if (time < 1) {
              gameTimer.invalidate()
        self.removeAllChildren()
            
             GameOverTimer = Timer.scheduledTimer(timeInterval:4, target: self, selector: #selector(gameOverNow), userInfo: nil, repeats: true)
            
            highscore = score
            
            
      //      print("New high score shall come")
       //     print("New Highscore\(highscore)")
        }
    }
    // this will make sure the bubbles don't overlap
    

    
    func gameOverNow() {
         self.removeAllChildren()
    }
   
    func addAlien () {
        ChangeBubleTime = 1
      
      //  print("Speed they come\(SpeedThatBubblesCome)")
       //  print("speed of aliens:\(HowManyBubbles)")
        
        //// amount they appear
        
        possibleAliens = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: possibleAliens) as! [String]
        
        let Bubble = SKSpriteNode(imageNamed: possibleAliens[0])
        
        
        var randomAlienPosition = GKRandomDistribution(lowestValue: 40, highestValue: 374)
        var position = CGFloat(randomAlienPosition.nextInt())
        
        
        if (CheckingBubblesDontOverlapx != nil) {
           
            var checkingNow =  CheckingBubblesDontOverlapx - Int(position)
            
            while (checkingNow < 75 && checkingNow > -75) {
                
                randomAlienPosition = GKRandomDistribution(lowestValue: 40, highestValue: 374)
                position = CGFloat(randomAlienPosition.nextInt())
                checkingNow =  CheckingBubblesDontOverlapx - Int(position)
            }
        } else {
              CheckingBubblesDontOverlapx = Int(position)
        }
        
        Bubble.position = CGPoint(x: position, y: self.frame.size.height + Bubble.size.height)
        
        Bubble.physicsBody = SKPhysicsBody(rectangleOf: Bubble.size)
        Bubble.physicsBody?.isDynamic = true
        
        Bubble.physicsBody?.categoryBitMask = alienCategory
        Bubble.physicsBody?.contactTestBitMask = photonTorpedoCategory
        Bubble.physicsBody?.collisionBitMask = 0
        
       CheckingBubblesDontOverlapx = Int(position)
        
        self.addChild(Bubble)
        
        let animationDuration:TimeInterval = 6
        
        var actionArray = [SKAction]()
        
        
        actionArray.append(SKAction.move(to: CGPoint(x: position, y: -Bubble.size.height), duration: animationDuration))
        actionArray.append(SKAction.removeFromParent())
        
        Bubble.run(SKAction.sequence(actionArray))
        
    
    }
    
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
       
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
                let torpedoNode = SKSpriteNode(imageNamed: "torpedo")
        
        possibleAliens = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: possibleAliens) as! [String]
        
        let Bubble = SKSpriteNode(imageNamed: possibleAliens[0])
      
        
        if let touch = touches.first {
          
            self.run(SKAction.playSoundFileNamed("torpedo.mp3", waitForCompletion: false))
            
            let torpedoNode = SKSpriteNode(imageNamed: "torpedo")
            torpedoNode.position = touch.location(in: self)
            
            
            torpedoNode.physicsBody = SKPhysicsBody(circleOfRadius: torpedoNode.size.width / 2)
            torpedoNode.physicsBody?.isDynamic = true
            
            torpedoNode.physicsBody?.categoryBitMask = photonTorpedoCategory
            torpedoNode.physicsBody?.contactTestBitMask = alienCategory
            torpedoNode.physicsBody?.collisionBitMask = 0
            torpedoNode.physicsBody?.usesPreciseCollisionDetection = true
            
            self.addChild(torpedoNode)
            
            let animationDuration:TimeInterval = 0.3
            
            
            var actionArray = [SKAction]()
            
            actionArray.append(SKAction.move(to: CGPoint(x: touch.location(in: self).x, y: self.frame.size.height + 10), duration: animationDuration))
            actionArray.append(SKAction.removeFromParent())
            
            torpedoNode.run(SKAction.sequence(actionArray))
            
            
            
            
       
        }
    }
    
    
    
    
    func didBegin(_ contact: SKPhysicsContact) {
        var firstBody:SKPhysicsBody
        var secondBody:SKPhysicsBody
        
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
            firstBody = contact.bodyA
            secondBody = contact.bodyB
        }else{
            firstBody = contact.bodyB
            secondBody = contact.bodyA
        }
        
        if (firstBody.categoryBitMask & photonTorpedoCategory) != 0 && (secondBody.categoryBitMask & alienCategory) != 0 {
           torpedoDidCollideWithAlien(torpedoNode: firstBody.node as! SKSpriteNode, alienNode: secondBody.node as! SKSpriteNode)
        }
        
    }
    
    
    override func update(_ currentTime: CFTimeInterval) {
        // Loop over all nodes in the scene
        self.enumerateChildNodes(withName: "*") {
            node, stop in
            if (node is SKSpriteNode) {
                let sprite = node as! SKSpriteNode
                // Check if the node is not in the scene
                if (sprite.position.y < -sprite.size.height/2.0) {
                    time = time - 1
                }
            }
        }
    }
    
    func torpedoDidCollideWithAlien (torpedoNode:SKSpriteNode, alienNode:SKSpriteNode) {
    
        let explosion = SKEmitterNode(fileNamed: "Explosion")!
        explosion.position = alienNode.position
        self.addChild(explosion)
        
        self.run(SKAction.playSoundFileNamed("explosion.mp3", waitForCompletion: false))

        /// ok remove the rest of the crap around the name.
        let string = (String(describing: alienNode.texture!))
        var FormattedString = string.replacingOccurrences(of: "<SKTexture>", with: "")
        FormattedString = FormattedString.replacingOccurrences(of: "'", with: "")
        FormattedString = FormattedString.replacingOccurrences(of: "(90 x 95)", with: "")
         FormattedString = FormattedString.replacingOccurrences(of: " ", with: "")


        
        
  //      print("FormattedString is :\(FormattedString)")
        
        // end of removal
        
        torpedoNode.removeFromParent()
        alienNode.removeFromParent()
        
        
        self.run(SKAction.wait(forDuration: 2)) { 
            explosion.removeFromParent()
        }
     //   print(FormattedString)
        if (FormattedString == "RedBubbles") {
            if (previousString == "RedBubbles") {
                BetterScore = 1
                let score2 = score + Double(1 * 1.5)
                score = score2
            } else {
           let score2 = score + 1
            score = score2
                BetterScore = 0
            }
        } else if (FormattedString == "PinkBubbles") {
            if (previousString == "PinkBubbles") {
                BetterScore = 1
            let score2 = score + Double(2 * 1.5)
            score = score2
            } else {
                let score2 = score + 2
                score = score2
                 BetterScore = 0
            }
        } else if (FormattedString == "GreenBubbles") {
                if (previousString == "GreenBubbles") {
                    BetterScore = 1
            let score2 = score + Double(5 * 1.5)
            score = score2
                } else {
                    let score2 = score + 5
                    score = score2
                     BetterScore = 0
            }
        } else if (FormattedString == "BlueBubbles") {
                    if (previousString == "BlueBubbles") {
                        BetterScore = 1
            let score2 = score + Double(8 * 1.5)
            score = score2
                    } else {
                        let score2 = score + 8
                        score = score2
                         BetterScore = 0
            }
        } else if (FormattedString == "BlackBubbles") {
                        if (previousString == "BlackBubbles") {
                            BetterScore = 1
            let score2 = score + Double(10 * 1.5)
            score = score2
                        } else {
                            let score2 = score + 10
                            score = score2
                             BetterScore = 0
            }
        }  else if (FormattedString == "YellowBubbles") {
            let score2 = score + 1000
            score = score2
        }
        
        previousString = FormattedString
        
    }
    
    override func didSimulatePhysics() {
        
   
        
    }
    
   
    
    
    

}
