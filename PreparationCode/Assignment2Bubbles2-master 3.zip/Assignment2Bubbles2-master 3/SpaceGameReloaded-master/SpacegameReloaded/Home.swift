//
//  Home.swift
//  SpacegameReloaded
//
//  Created by Joshua Parker on 1/5/18.
//  Copyright © 2018 Training. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit

class Home: UIViewController {
    
    var circleRecognizer: GameScene!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }
    
}
